package com.example.jarvis

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The arc-reactor drawing. Spins always, pulses while Jarvis listens or speaks. */
class Reactor(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF22E0FF.toInt() }
    private var angle = 0f
    var active = false
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 8000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 14f
        val k = if (active) (1.0 + 0.05 * Math.sin(Math.toRadians(angle * 6.0))).toFloat() else 1f
        p.strokeWidth = 5f
        p.setShadowLayer(if (active) 40f else 18f, 0f, 0f, p.color)
        c.drawCircle(cx, cy, r * k, p)
        p.strokeWidth = 4f
        p.pathEffect = DashPathEffect(floatArrayOf(18f, 14f), 0f)
        c.save(); c.rotate(angle, cx, cy); c.drawCircle(cx, cy, r * 0.8f * k, p); c.restore()
        p.pathEffect = null
        p.strokeWidth = 5f
        c.save(); c.rotate(-angle * 1.6f, cx, cy)
        c.drawArc(RectF(cx - r * 0.58f, cy - r * 0.58f, cx + r * 0.58f, cy + r * 0.58f), 0f, 240f, false, p)
        c.restore()
        p.style = Paint.Style.FILL
        c.drawCircle(cx, cy, r * 0.26f * k, p)
        p.style = Paint.Style.STROKE
    }
}

class MainActivity : Activity() {
    private lateinit var tts: TextToSpeech
    private lateinit var reactor: Reactor
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var lockMsg: TextView
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var arabic = true
    private val ui = Handler(Looper.getMainLooper())

    // spoken name -> package, for opening apps
    private val apps = mapOf(
        "واتساب" to "com.whatsapp", "whatsapp" to "com.whatsapp",
        "يوتيوب" to "com.google.android.youtube", "youtube" to "com.google.android.youtube",
        "خرائط" to "com.google.android.apps.maps", "maps" to "com.google.android.apps.maps",
        "تيليجرام" to "org.telegram.messenger", "telegram" to "org.telegram.messenger",
        "انستجرام" to "com.instagram.android", "instagram" to "com.instagram.android",
        "سناب" to "com.snapchat.android", "snapchat" to "com.snapchat.android",
        "تيك توك" to "com.zhiliaoapp.musically", "tiktok" to "com.zhiliaoapp.musically",
        "سبوتيفاي" to "com.spotify.music", "spotify" to "com.spotify.music",
        "كروم" to "com.android.chrome", "chrome" to "com.android.chrome",
        "جيميل" to "com.google.android.gm", "gmail" to "com.google.android.gm",
        "الاعدادات" to "com.android.settings", "الإعدادات" to "com.android.settings", "settings" to "com.android.settings"
    )

    private fun tr(a: String, e: String) = if (arabic) a else e
    private fun loc() = Locale.forLanguageTag(if (arabic) "ar" else "en-US")
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF04121A.toInt()
        val ac = 0xFF22E0FF.toInt()
        val dim = 0xFF7FA7B6.toInt()
        val fg = 0xFFD6F6FF.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val heading = TextView(this).apply { text = "J.A.R.V.I.S"; setTextColor(ac); textSize = 22f; gravity = Gravity.CENTER }
        reactor = Reactor(this).apply { setOnClickListener { listen() } }
        status = TextView(this).apply { text = "اضغط على المفاعل وتحدث"; setTextColor(dim); gravity = Gravity.CENTER }
        log = TextView(this).apply { setTextColor(fg); textSize = 16f }
        scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply {
            hint = "أو اكتب الأمر هنا"
            setHintTextColor(dim)
            setTextColor(fg)
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { v, _, _ ->
                val s = v.text.toString().trim()
                if (s.isNotEmpty()) { v.text = ""; handle(s) }
                true
            }
        }
        val lang = Button(this).apply {
            text = "AR"
            setOnClickListener { arabic = !arabic; text = if (arabic) "AR" else "EN"; setTts() }
        }
        val row = LinearLayout(this).apply {
            addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(lang)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            addView(heading)
            addView(reactor, LinearLayout.LayoutParams(dp(190), dp(190)).apply { topMargin = dp(16); bottomMargin = dp(8) })
            addView(status)
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(12) })
            addView(row)
        }
        lockMsg = TextView(this).apply {
            text = "اضغط للتحقق من هويتك"
            setTextColor(ac)
            textSize = 20f
            gravity = Gravity.CENTER
            setOnClickListener { lock() }
        }
        content.visibility = View.INVISIBLE
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(bg)
            fitsSystemWindows = true
            addView(content, FrameLayout.LayoutParams(-1, -1))
            addView(lockMsg, FrameLayout.LayoutParams(-1, -1))
        })

        tts = TextToSpeech(this) { s -> ttsReady = s == TextToSpeech.SUCCESS; if (ttsReady) setTts() }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { runOnUiThread { reactor.active = true } }
            override fun onDone(id: String?) { runOnUiThread { reactor.active = false } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { runOnUiThread { reactor.active = false } }
        })
        ui.postDelayed({ lock() }, 400)
    }

    private fun setTts() { if (ttsReady) tts.setLanguage(loc()) }

    // ---- biometric lock: fingerprint / face if the phone allows it, otherwise the phone's PIN ----
    private fun lock() {
        val prompt = BiometricPrompt.Builder(this)
            .setTitle("جارفس")
            .setSubtitle("تحقق من هويتك للمتابعة")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { unlock() }
            override fun onAuthenticationError(code: Int, msg: CharSequence?) {
                // timeout, cancel, lockout, user cancel -> stay locked; no lock screen set on the phone -> open
                if (code in listOf(3, 5, 7, 9, 10, 13)) lockMsg.text = "اضغط للتحقق من هويتك" else unlock()
            }
        })
    }

    private fun unlock() {
        lockMsg.visibility = View.GONE
        content.visibility = View.VISIBLE
        if (log.text.isEmpty()) say(tr("جارفس جاهز يا سيدي. كيف أساعدك؟", "Jarvis online, sir. How can I help?"))
    }

    // ---- output ----
    private fun add(t: String) {
        log.append(t + "\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun say(t: String) {
        add("🤖 $t")
        if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "j")
    }

    private fun go(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { say(tr("تعذر فتح ذلك", "Couldn't open that")) }
    }

    private fun web(q: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))

    // ---- voice input ----
    private fun listen() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say(tr("خدمة التعرف على الصوت غير متاحة", "Speech recognition is unavailable")); return
        }
        if (ttsReady) tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = tr("أستمع إليك...", "Listening..."); reactor.active = true }
                override fun onResults(res: Bundle?) {
                    done()
                    res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
                }
                override fun onError(e: Int) { done(); status.text = tr("لم أسمعك، حاول مرة أخرى", "Didn't catch that, try again") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, tr("ar-SA", "en-US"))
            )
        }
    }

    private fun done() { reactor.active = false; status.text = tr("اضغط على المفاعل وتحدث", "Tap the core and speak") }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && granted(Manifest.permission.RECORD_AUDIO)) listen()
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }

    // ---- commands ----
    private fun handle(raw: String) {
        add("🗣 $raw")
        val clean = raw.replace(Regex("[\\u064B-\\u0652]"), "").trim()
        val t = clean.lowercase().replace(Regex("^(جارفس|جارفيس|جاروس|jarvis)[ ,،]*"), "")
        val digits = t.map { if (it in '٠'..'٩') '0' + (it - '٠') else it }.joinToString("")
        val num = Regex("\\+?\\d[\\d ]{6,}").find(digits)?.value?.replace(" ", "")
        fun has(vararg w: String) = w.any { t.contains(it) }
        fun rest(vararg p: String) = t.replace(Regex("^(" + p.joinToString("|") + ")\\s*"), "").trim()

        when {
            has("اتصل", "كلم", "call") -> call(num, rest("اتصل ب", "اتصل", "كلم", "call"))
            has("كاميرا", "camera") -> { say(tr("أفتح الكاميرا", "Opening the camera")); go(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) }
            has("كشاف", "فلاش", "flashlight", "torch") -> flash(!has("اطفئ", "أطفئ", "اغلق", "off"))
            t.startsWith("شغل") || t.startsWith("play") -> play(rest("شغل", "play"))
            t.startsWith("افتح") || t.startsWith("open") -> openApp(rest("افتح", "open"))
            has("خذني", "وصلني", "navigate", "take me") -> {
                val d = rest("خذني إلى", "خذني الى", "خذني", "وصلني إلى", "وصلني الى", "وصلني", "navigate to", "take me to")
                say(tr("أحدد لك الطريق إلى ", "Navigating to ") + d)
                go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(d))))
            }
            has("ابحث", "search") -> {
                val q = rest("ابحث عن", "ابحث", "search for", "search")
                say(tr("أبحث عن ", "Searching for ") + q); web(q)
            }
            has("طقس", "weather") -> { say(tr("أفتح لك حالة الطقس", "Checking the weather")); web(tr("الطقس", "weather")) }
            has("الساعة", "الوقت", "time") -> say(tr("الساعة الآن ", "It is ") + SimpleDateFormat("h:mm a", loc()).format(Date()))
            has("التاريخ", "اليوم", "date", "today") -> say(SimpleDateFormat("EEEE d MMMM yyyy", loc()).format(Date()))
            has("بطارية", "battery") -> {
                val b = (getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                say(tr("مستوى البطارية $b بالمئة", "Battery is at $b percent"))
            }
            has("ارفع الصوت", "أرفع الصوت", "volume up") -> volume(true)
            has("اخفض الصوت", "أخفض الصوت", "volume down") -> volume(false)
            has("مرحبا", "اهلا", "أهلا", "السلام") || Regex("\\b(hello|hi|hey)\\b").containsMatchIn(t) ->
                say(tr("أهلاً بك سيدي، كيف أساعدك؟", "Welcome, sir. How can I help?"))
            else -> { say(tr("لم أفهم الأمر، سأبحث عنه في جوجل", "I didn't get that, searching Google")); web(clean) }
        }
    }

    private fun call(num: String?, name: String) {
        val n = num ?: findContact(name)
        if (n == null) { say(tr("لم أجد هذا الرقم أو الاسم", "I couldn't find that number or contact")); return }
        say(tr("أتصل بـ ", "Calling ") + (if (num == null) name else n))
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        go(Intent(action, Uri.parse("tel:" + Uri.encode(n))))
    }

    private fun findContact(name: String): String? {
        if (name.isBlank() || !granted(Manifest.permission.READ_CONTACTS)) return null
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun play(q: String) {
        if (q.isBlank()) { say(tr("ماذا تريد أن أشغّل؟", "What should I play?")); return }
        if (apps.containsKey(q)) { openApp(q); return }
        val spotify = q.contains("سبوتيفاي") || q.contains("spotify")
        val k = q.replace(Regex("\\s*(في|على|on|in)\\s*(يوتيوب|سبوتيفاي|youtube|spotify)$"), "")
        say(tr("أشغّل ", "Playing ") + k)
        val url = if (spotify) "spotify:search:" + Uri.encode(k) else "https://www.youtube.com/results?search_query=" + Uri.encode(k)
        go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun openApp(name: String) {
        if (name.isBlank()) { say(tr("أي تطبيق تريد؟", "Which app?")); return }
        val pm = packageManager
        var intent: Intent? = apps.entries.firstOrNull { name.contains(it.key) }?.let { pm.getLaunchIntentForPackage(it.value) }
        if (intent == null) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val hit = pm.queryIntentActivities(main, 0).firstOrNull {
                val l = it.loadLabel(pm).toString().lowercase()
                l.isNotBlank() && (l.contains(name) || name.contains(l))
            }
            intent = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        }
        if (intent == null) {
            say(tr("لم أجد تطبيق $name", "I couldn't find $name"))
        } else {
            say(tr("أفتح $name", "Opening $name"))
            go(intent)
        }
    }

    private fun flash(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { say(tr("لا يوجد فلاش في هذا الجهاز", "No flashlight found")); return }
            cm.setTorchMode(id, on)
            say(tr(if (on) "شغّلت الكشاف" else "أطفأت الكشاف", if (on) "Flashlight on" else "Flashlight off"))
        } catch (e: Exception) {
            say(tr("تعذر التحكم بالكشاف", "Couldn't control the flashlight"))
        }
    }

    private fun volume(up: Boolean) {
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }
}
