جارفس - تطبيق أندرويد (Iron Man style)

الخطوات على الحاسوب:
1) ثبّت Android Studio (من developer.android.com/studio).
2) New Project > Empty Views Activity، ثم اضبط:
   Name: Jarvis
   Package name: com.example.jarvis   (يجب أن يكون هكذا تمامًا)
   Language: Kotlin
   Minimum SDK: API 30
3) استبدل محتوى هذين الملفين بالملفين الموجودين هنا (غيّر عرض المشروع إلى Project):
   app/src/main/AndroidManifest.xml
   app/src/main/java/com/example/jarvis/MainActivity.kt
4) على الجوال: الإعدادات > حول الهاتف > معلومات البرنامج > اضغط "رقم البناء" 7 مرات.
   ثم من خيارات المطور فعّل "تصحيح USB".
5) وصّل الجوال بالكابل ووافق على نافذة التصحيح، اختر جوالك في أعلى Android Studio، واضغط Run (المثلث الأخضر).
   سيُثبَّت التطبيق ويعمل على الجوال وحده بعد ذلك.
6) لملف APK مستقل: Build > Build Bundle(s) / APK(s) > Build APK(s).

عند أول تشغيل اسمح بالميكروفون والاتصال وجهات الاتصال.

أوامر جرّبها: افتح واتساب / شغل فيروز / اتصل بأحمد / اتصل 0501234567 /
افتح الكاميرا / شغل الكشاف / كم الساعة / كم البطارية / خذني إلى المطار /
ابحث عن الطقس / ارفع الصوت
